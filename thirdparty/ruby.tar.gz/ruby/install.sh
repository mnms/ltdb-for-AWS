#!/bin/bash

DEPLOY_DIR="$HOME/flashbase"
RUBY_DIR="$DEPLOY_DIR/packages/ruby"
GEM_DIR="$RUBY_DIR/gemfile"

cd $RUBY_DIR

sudo yum install -y git
git clone git://github.com/sstephenson/rbenv.git ~/.rbenv

# .bashrc .bash_profile 
cat bashrc_ruby >> ~/.bashrc

cd ~/.rbenv
mkdir plugins
cd plugins/
git clone git://github.com/sstephenson/ruby-build.git

cd ruby-build/
sudo ./install.sh
cd ~

. ~/.bashrc

sudo yum install -y gcc
sudo yum install -y openssl-devel readline-devel zlib-devel

rbenv install 2.6.4
rbenv rehash
rbenv global 2.6.4

gem install bundler
rbenv rehash

cd $GEM_DIR

bundle install

cd $DEPLOY_DIR
